{-
Want to use this, don't know how?
You'll need something to interpret or compile Haskell with.
I recommend one found here: http://www.haskell.org/ghc/

The description of assembly I use is peculiar, but I find it easier to write.
The command:

SET A 5 ;
Sets register A to the value 5. The semicolon is needed and must be spaced out.
Alternatively, you could do:
SET A N ; 5
N means "next word." 

To access RAM, use N*. It refers to the RAM at the next word:
SET N* A ; x0010

The second word is literal hex and after the x will be exactly how it shows up in compiled code.
The x is needed. Make sure it's exactly 4 letters.

[register] is *register
[next word + register] is N*register

When this program is compiled, it will ask you for a file name. It will load in the file, produce the output as a 
compiled file with the same name and extension ".dcup" 
-}






hexes = "0123456789abcdef"

bin_hex (a:b:c:d:r) = hexes !! (d + c*2 + b*4 + a*8) : bin_hex r
bin_hex [] = []

str_bin ('0':z) = 0 : str_bin z
str_bin ('1':z) = 1 : str_bin z
str_bin [] = []

str_hex = bin_hex . str_bin




data Source = C String | S String
to_source = map S

num_bin' x 0 = []
num_bin' x n = if x >= n then 1 : num_bin' (x - n) (n `div` 2) else 0 : num_bin' x (n `div` 2)
num_bin16 x = num_bin' x 8
num_bin32 x = num_bin' x 16
num_bin64 x = num_bin' x 32
num_bin4h x = num_bin' x 32768

commands = ["","SET","ADD","SUB","MUL","DIV","MOD","SHL","SHR","AND","BOR","XOR","IFE","IFN","IFG","IFB"]
cmd_bin x = list_bin' x commands 0
list_bin list x = list_bin' x list 0
list_bin' x (a:z) i
	|x == a = num_bin16 i
	|True   = list_bin' x z (i+1)
list_bin64 list x = list_bin64' x list 0
list_bin64' x (a:z) i
	|x == a = num_bin64 i
	|True   = list_bin64' x z (i+1)
regs = ["A","B","C","X","Y","Z","I","J"]
values = regs ++ map ("*"++) regs ++ map ("N*"++) regs ++ ["POP","PEEK","PUSH","SP","PC","O","*N","N"] ++ map show [0..31]

value v = list_bin64 values v



locator (a : ":" : z) n k
	|a == n = k
	|otherwise = locator z n k -- No increment
locator (cmd : a : b : ";" : z) n k = locator z n (k+1)
locator ("//" : z) n k = lcomments z n k
locator (x : z) n k = locator z n (k+1)
lcomments ("//" : z) n k = locator z n k
lcomments (_ : z) n k = lcomments z n k



assemble s [] = []
assemble s ("//" : z) = comments s z
assemble s (_ : ":" : z) = assemble s z--Locations
assemble s ("JMP" : a : ";" : z) = assemble s ("SET" : "PC" : "N" : ";" : a : z)
assemble s (cmd : a : b : ";" : z) = bin_hex (value b ++ value a ++ cmd_bin cmd) ++ assemble s z
assemble s (x : z)
	|head x == 'x' = tail x ++ assemble s z --For raw hex data. Ex: x1000
	|head x == '!' = (bin_hex . num_bin4h) (locator s (tail x) 0) ++ assemble s z
	|True = (bin_hex $ num_bin4h $ read $ x) ++ assemble s z --For numbers. All for now.

comments s ("//" : z) = assemble s z
comments s (_ : z) = comments s z
comments s [] = []

groupit [] = []
groupit (a:b:c:d:z) = a:b:c:d:' ':groupit z



pickFile = do
	putStrLn "  File? Will read Input/[yourfile].src, saves to Output/[yourfile].dcpu"
	putStr " >"
	cf <- getLine
	return cf


main = do
	cf <- pickFile
	c <- readFile ("Input/" ++ cf ++ ".src")
	let q = assemble (words c) $ words c
	let h = groupit q
	putStrLn "  Result: "
	putStrLn $ "  " ++ h
	putStrLn $ "  Saving to file Output/" ++ cf ++ ".dcpu"
	writeFile ("Output/" ++ cf ++ ".dcpu") h
	main